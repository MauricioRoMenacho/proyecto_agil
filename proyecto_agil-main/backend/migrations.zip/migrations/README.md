# Migraciones de la base de datos

Scripts SQL para crear la base de datos del Proyecto Ágil. Se ejecutan **en orden**.

| Archivo | Qué hace |
|---|---|
| `001_create_tables.sql` | Crea las 4 tablas y sus relaciones (usuarios, categorias, activos, movimientos). |
| `002_seed_data.sql` | Inserta datos de prueba. Las contraseñas ya están hasheadas con bcrypt. |

## Opción A — Supabase

1. Entra a tu proyecto en Supabase → menú **SQL Editor**.
2. Copia el contenido de `001_create_tables.sql`, pégalo y presiona **Run**.
3. Repite con `002_seed_data.sql`.
4. En **Project Settings → Database** copia la *Connection string* y ponla en el `.env` del backend como `DATABASE_URL`, y agrega `DB_SSL=true`.

## Opción B — PostgreSQL local (pgAdmin / psql)

1. Crea la base de datos: `CREATE DATABASE proyecto_agil;`
2. Conéctate a ella y ejecuta primero `001_create_tables.sql`, luego `002_seed_data.sql`.
3. En el `.env` usa las variables sueltas (`DB_HOST`, `DB_PORT`, etc.). No hace falta `DATABASE_URL`.

## Usuarios de prueba

| Usuario | Contraseña |
|---|---|
| `admin` | `admin123` |
| `supervisor` | `super123` |
